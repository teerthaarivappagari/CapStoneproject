package com.aits.PrepaidRechargeProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrepaidRechargeProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
