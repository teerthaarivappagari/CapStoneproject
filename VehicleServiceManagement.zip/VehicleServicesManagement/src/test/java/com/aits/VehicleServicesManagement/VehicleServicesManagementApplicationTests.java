package com.aits.VehicleServicesManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VehicleServicesManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
