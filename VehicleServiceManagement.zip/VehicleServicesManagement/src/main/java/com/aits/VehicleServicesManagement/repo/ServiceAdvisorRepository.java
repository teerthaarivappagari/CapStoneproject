package com.aits.VehicleServicesManagement.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.aits.VehicleServicesManagement.entity.ServiceAdvisor;

public interface ServiceAdvisorRepository extends JpaRepository<ServiceAdvisor, Long> {

}
